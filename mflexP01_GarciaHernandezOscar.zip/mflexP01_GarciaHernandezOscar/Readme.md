* Título del proyecto *;
# maquetacionFLEX_Practica01;
* Descripción del proyecto *
Práctica perteneciente a maquetación
> usando Flex
* Contenido de la publicación *
Contiene un HTML, un CSS y una carpeta de imágenes
* Desarrollo del proyecto *
El proyecto se entregó el sábado, 12 de diciembre de 2020, 23:00
* Despliegue *
Link a la página principal [GitHub Pages](https://github.com/)
* Construido con *
Visual Studio Code
* Versionado *
1.0
* Autores *
Óscar García Hernández
* Licencia *
Ninguna
* Recursos adicionales *
Link a mi página principal [GitHub Pages](https://github.com/oscargh0901)
